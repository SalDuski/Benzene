/** Minimal inline SVG icons — 20px grid, stroke inherits currentColor. */

const base = {
  width: 20,
  height: 20,
  viewBox: "0 0 20 20",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: 2,
  strokeLinecap: "round",
  strokeLinejoin: "round",
  "aria-hidden": true,
};

export function PauseIcon() {
  return (
    <svg {...base}>
      <path d="M7 4v12M13 4v12" />
    </svg>
  );
}

export function PlayIcon() {
  return (
    <svg {...base}>
      <path d="M6 4l10 6-10 6V4z" fill="currentColor" stroke="none" />
    </svg>
  );
}

export function SoundIcon() {
  return (
    <svg {...base}>
      <path d="M3 8v4h3l4 3V5L6 8H3z" fill="currentColor" stroke="none" />
      <path d="M13 7a4 4 0 010 6M15.5 5a7 7 0 010 10" strokeWidth={1.6} />
    </svg>
  );
}

export function MutedIcon() {
  return (
    <svg {...base}>
      <path d="M3 8v4h3l4 3V5L6 8H3z" fill="currentColor" stroke="none" />
      <path d="M13 8l4 4M17 8l-4 4" strokeWidth={1.6} />
    </svg>
  );
}

export function LockIcon() {
  return (
    <svg {...base} strokeWidth={1.7}>
      <rect x="4.5" y="9" width="11" height="7.5" rx="1.5" />
      <path d="M7 9V6.5a3 3 0 016 0V9" />
    </svg>
  );
}

export function CheckIcon() {
  return (
    <svg {...base}>
      <path d="M4 10.5l4 4 8-9" />
    </svg>
  );
}

export function StarIcon() {
  return (
    <svg {...base} width={14} height={14} strokeWidth={1.6}>
      <path d="M10 2.5l2.3 4.7 5.2.8-3.8 3.7.9 5.2-4.6-2.5-4.6 2.5.9-5.2L2.5 8l5.2-.8L10 2.5z" />
    </svg>
  );
}
export function BackIcon() {
  return (
    <svg {...base}>
      <path d="M12 4l-6 6 6 6" />
    </svg>
  );
}

export function StepInIcon() {
  return (
    <svg {...base}>
      <path d="M4 13l6-6 6 6" />
    </svg>
  );
}

export function StepBackIcon() {
  return (
    <svg {...base}>
      <path d="M4 7l6 6 6-6" />
    </svg>
  );
}
